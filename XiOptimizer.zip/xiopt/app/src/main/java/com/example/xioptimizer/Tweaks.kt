package com.example.xioptimizer

/** Одна настраиваемая функция: что делает включение и как это откатить. */
data class Tweak(
    val id: String,
    val title: String,
    val description: String,
    val apply: List<String>,
    val revert: List<String>,
    val risky: Boolean = false
)

/** Одноразовое действие (кнопка), без отката. quiet = показывать только вывод команд. */
data class Action(
    val id: String,
    val title: String,
    val description: String,
    val commands: List<String>,
    val quiet: Boolean = false
)

/** Профиль: набор функций, который включается одним нажатием. */
data class Profile(
    val id: String,
    val title: String,
    val description: String,
    val tweakIds: Set<String>,
    val actionIds: Set<String> = emptySet()
)

object Tweaks {

    private val animReset = listOf(
        "settings put global window_animation_scale 1.0",
        "settings put global transition_animation_scale 1.0",
        "settings put global animator_duration_scale 1.0"
    )

    val toggles = listOf(
        // ---------- Безопасные ----------
        Tweak(
            id = "anim_fast",
            title = "Быстрые анимации (0.5x)",
            description = "Ускоряет переходы и открытие окон, телефон ощущается шустрее.",
            apply = listOf(
                "settings put global window_animation_scale 0.5",
                "settings put global transition_animation_scale 0.5",
                "settings put global animator_duration_scale 0.5"
            ),
            revert = animReset
        ),
        Tweak(
            id = "anim_off",
            title = "Выключить анимации",
            description = "Максимальная отзывчивость, но интерфейс выглядит резче.",
            apply = listOf(
                "settings put global window_animation_scale 0",
                "settings put global transition_animation_scale 0",
                "settings put global animator_duration_scale 0"
            ),
            revert = animReset
        ),
        Tweak(
            id = "refresh_high",
            title = "Экран 90 Гц постоянно",
            description = "У Redmi Note 11 экран AMOLED 90 Гц. Фиксирует 90 Гц вместо автоматического переключения: плавнее, но батарея садится быстрее.",
            apply = listOf(
                "settings put system min_refresh_rate 90.0",
                "settings put system peak_refresh_rate 90.0"
            ),
            revert = listOf(
                "settings delete system min_refresh_rate",
                "settings delete system peak_refresh_rate"
            )
        ),
        Tweak(
            id = "refresh_60",
            title = "Экран 60 Гц (экономия)",
            description = "Фиксирует 60 Гц, чтобы батарея держалась дольше. Не работает одновременно с режимом 90 Гц.",
            apply = listOf(
                "settings put system min_refresh_rate 60.0",
                "settings put system peak_refresh_rate 60.0"
            ),
            revert = listOf(
                "settings delete system min_refresh_rate",
                "settings delete system peak_refresh_rate"
            )
        ),
        Tweak(
            id = "disable_msa",
            title = "Отключить рекламные сервисы Xiaomi (MSA)",
            description = "Убирает рекламу в системных приложениях MIUI/HyperOS и снижает фоновую нагрузку. Полностью обратимо.",
            apply = listOf(
                "pm disable-user --user 0 com.miui.msa.global",
                "pm disable-user --user 0 com.miui.analytics"
            ),
            revert = listOf(
                "pm enable com.miui.msa.global",
                "pm enable com.miui.analytics"
            )
        ),
        Tweak(
            id = "miui_junk",
            title = "Убрать мусор MIUI на Note 11",
            description = "Отключает «Обои-карусель», GetApps (магазин с рекомендациями), Xiaomi Games и «Услуги и отзывы». Всё это крутится в фоне и показывает рекламу. Обратимо; без GetApps приложения Xiaomi обновляются через Google Play.",
            apply = listOf(
                "pm disable-user --user 0 com.miui.android.fashiongallery",
                "pm disable-user --user 0 com.xiaomi.mipicks",
                "pm disable-user --user 0 com.xiaomi.glgm",
                "pm disable-user --user 0 com.miui.miservice"
            ),
            revert = listOf(
                "pm enable com.miui.android.fashiongallery",
                "pm enable com.xiaomi.mipicks",
                "pm enable com.xiaomi.glgm",
                "pm enable com.miui.miservice"
            )
        ),
        Tweak(
            id = "fb_off",
            title = "Отключить Facebook-сервисы",
            description = "На многих Poco и Redmi предустановлены фоновые сервисы Facebook. Если их нет, ничего не произойдёт.",
            apply = listOf(
                "pm disable-user --user 0 com.facebook.appmanager",
                "pm disable-user --user 0 com.facebook.services",
                "pm disable-user --user 0 com.facebook.system"
            ),
            revert = listOf(
                "pm enable com.facebook.appmanager",
                "pm enable com.facebook.services",
                "pm enable com.facebook.system"
            )
        ),
        Tweak(
            id = "wifi_scan_off",
            title = "Отключить фоновый поиск Wi-Fi и Bluetooth",
            description = "Система перестаёт сканировать сети, когда Wi-Fi и Bluetooth выключены. Экономит батарею.",
            apply = listOf(
                "settings put global wifi_scan_always_enabled 0",
                "settings put global ble_scan_always_enabled 0"
            ),
            revert = listOf(
                "settings put global wifi_scan_always_enabled 1",
                "settings put global ble_scan_always_enabled 1"
            )
        ),
        Tweak(
            id = "night_system",
            title = "Тёмная тема системы",
            description = "Включает системную тёмную тему. На AMOLED-экранах экономит заряд.",
            apply = listOf("cmd uimode night yes"),
            revert = listOf("cmd uimode night no")
        ),
        Tweak(
            id = "stay_awake",
            title = "Экран не гаснет при зарядке",
            description = "Пока телефон на зарядке, экран остаётся включённым. Удобно для настройки и тестов.",
            apply = listOf("settings put global stay_on_while_plugged_in 3"),
            revert = listOf("settings put global stay_on_while_plugged_in 0")
        ),
        Tweak(
            id = "dns_fast",
            title = "Быстрый DNS (Cloudflare)",
            description = "Включает Private DNS one.one.one.one. Часто ускоряет открытие сайтов. Откат вернёт автоматический режим.",
            apply = listOf(
                "settings put global private_dns_mode hostname",
                "settings put global private_dns_specifier one.one.one.one"
            ),
            revert = listOf("settings put global private_dns_mode opportunistic")
        ),

        // ---------- НА СВОЙ РИСК ----------
        Tweak(
            id = "limit_bg",
            title = "Лимит фоновых приложений: 16",
            description = "У Note 11 4–6 ГБ RAM и Snapdragon 680. Система держит в памяти меньше приложений, больше свободной памяти и меньше лагов. Приложения чаще перезапускаются. Значение может сброситься после перезагрузки.",
            apply = listOf("device_config put activity_manager max_cached_processes 16"),
            revert = listOf("device_config delete activity_manager max_cached_processes"),
            risky = true
        ),
        Tweak(
            id = "freezer_off",
            title = "Отключить заморозку кэшированных приложений",
            description = "Убирает задержки при возврате в приложение, но чуть повышает расход батареи.",
            apply = listOf("settings put global cached_apps_freezer disabled"),
            revert = listOf("settings delete global cached_apps_freezer"),
            risky = true
        ),
        Tweak(
            id = "debloat_xiaomi",
            title = "Отключить лишние системные приложения Xiaomi",
            description = "Отключает bug report, MIUI Daemon, hybrid, рекламный solution. Может сломать мелкие системные функции. Откат вернёт всё.",
            apply = listOf(
                "pm disable-user --user 0 com.miui.bugreport",
                "pm disable-user --user 0 com.miui.daemon",
                "pm disable-user --user 0 com.miui.hybrid",
                "pm disable-user --user 0 com.miui.systemAdSolution"
            ),
            revert = listOf(
                "pm enable com.miui.bugreport",
                "pm enable com.miui.daemon",
                "pm enable com.miui.hybrid",
                "pm enable com.miui.systemAdSolution"
            ),
            risky = true
        ),
        Tweak(
            id = "joyose_off",
            title = "Отключить Joyose (управление производительностью)",
            description = "Joyose ограничивает частоты и игровые профили. Без него бывает меньше троттлинга, но телефон может сильнее греться, а игровой режим работать иначе.",
            apply = listOf("pm disable-user --user 0 com.xiaomi.joyose"),
            revert = listOf("pm enable com.xiaomi.joyose"),
            risky = true
        ),
        Tweak(
            id = "phantom_off",
            title = "Отключить убийцу фантомных процессов",
            description = "Android 12+ может внезапно закрывать фоновые процессы. Отключение стабилизирует работу, но повышает расход памяти.",
            apply = listOf("settings put global settings_enable_monitor_phantom_procs false"),
            revert = listOf("settings put global settings_enable_monitor_phantom_procs true"),
            risky = true
        ),
        Tweak(
            id = "verifier_off",
            title = "Отключить проверку приложений при установке по ADB",
            description = "Ускоряет установку приложений через ADB, но снижает защиту. Включай только если понимаешь зачем.",
            apply = listOf(
                "settings put global verifier_verify_adb_installs 0",
                "settings put global package_verifier_enable 0"
            ),
            revert = listOf(
                "settings put global verifier_verify_adb_installs 1",
                "settings put global package_verifier_enable 1"
            ),
            risky = true
        )
    )

    val actions = listOf(
        Action(
            id = "info",
            title = "Информация об устройстве",
            description = "Модель, версия системы, процессор, память, батарея.",
            quiet = true,
            commands = listOf(
                "echo Модель: \$(getprop ro.product.model)",
                "echo Android: \$(getprop ro.build.version.release)",
                "echo MIUI/HyperOS: \$(getprop ro.mi.os.version.name) \$(getprop ro.miui.ui.version.name)",
                "echo Платформа: \$(getprop ro.board.platform)",
                "echo Ядер CPU: \$(grep -c ^processor /proc/cpuinfo)",
                "echo Режим CPU: \$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)",
                "grep -E 'MemTotal|MemAvailable|SwapTotal' /proc/meminfo",
                "df -h /data | tail -1",
                "dumpsys battery | grep -E 'level|temperature'"
            )
        ),
        Action(
            id = "kill_bg",
            title = "Закрыть фоновые приложения",
            description = "Освобождает оперативную память прямо сейчас.",
            commands = listOf("am kill-all")
        ),
        Action(
            id = "trim_cache",
            title = "Очистить кэш всех приложений",
            description = "Удаляет временные файлы, освобождает место.",
            commands = listOf("pm trim-caches 999G")
        ),
        Action(
            id = "compile",
            title = "Оптимизировать приложения (dexopt)",
            description = "Перекомпилирует приложения для более быстрого запуска. Может занять несколько минут.",
            commands = listOf("cmd package compile -m speed-profile -a")
        ),
        Action(
            id = "bg_dexopt",
            title = "Запустить фоновую оптимизацию",
            description = "Запускает системное задание оптимизации, которое обычно идёт ночью на зарядке.",
            commands = listOf("cmd package bg-dexopt-job")
        ),
        Action(
            id = "fstrim",
            title = "TRIM памяти",
            description = "Говорит накопителю освободить неиспользуемые блоки. Помогает против замедления со временем.",
            commands = listOf("sm fstrim")
        ),
        Action(
            id = "clear_logs",
            title = "Очистить системные логи",
            description = "Сбрасывает буфер logcat.",
            commands = listOf("logcat -c")
        )
    )

    val profiles = listOf(
        Profile(
            id = "game",
            title = "🎮 Игры",
            description = "Быстрые анимации, экран 90 Гц, меньше фонового шума, очистка фона.",
            tweakIds = setOf("anim_fast", "refresh_high", "wifi_scan_off", "fb_off", "disable_msa", "miui_junk"),
            actionIds = setOf("kill_bg")
        ),
        Profile(
            id = "balance",
            title = "⚖️ Баланс",
            description = "Мягкое ускорение без ущерба для батареи: быстрые анимации, без рекламных сервисов и мусора MIUI.",
            tweakIds = setOf("anim_fast", "disable_msa", "fb_off", "miui_junk")
        ),
        Profile(
            id = "saver",
            title = "🔋 Экономия",
            description = "Экран 60 Гц, без анимаций, без фонового поиска сетей, тёмная тема системы. Для AMOLED Note 11 это заметно продлевает батарею.",
            tweakIds = setOf("refresh_60", "anim_off", "wifi_scan_off", "disable_msa", "fb_off", "miui_junk", "night_system")
        ),
        Profile(
            id = "ultra",
            title = "🚀 Ультра (на свой риск)",
            description = "Всё из «Игр» плюс агрессивные твики памяти. Рискованные пункты применяются только если включён режим «на свой риск».",
            tweakIds = setOf(
                "anim_fast", "refresh_high", "wifi_scan_off", "fb_off", "disable_msa", "miui_junk",
                "limit_bg", "freezer_off", "phantom_off"
            ),
            actionIds = setOf("kill_bg", "trim_cache")
        )
    )
}
