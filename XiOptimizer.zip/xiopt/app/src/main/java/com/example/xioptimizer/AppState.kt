package com.example.xioptimizer

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** Общее состояние: доступ к Shizuku, включённые функции, журнал, запуск команд. */
class AppState(
    private val prefs: SharedPreferences,
    private val scope: CoroutineScope
) {
    var shizukuReady by mutableStateOf(Shell.hasPermission())
        private set
    var busy by mutableStateOf(false)
        private set
    var log by mutableStateOf("")
        private set

    val enabled = mutableStateMapOf<String, Boolean>().apply {
        Tweaks.toggles.forEach { put(it.id, prefs.getBoolean(it.id, false)) }
    }

    fun refreshShizuku() {
        shizukuReady = Shell.hasPermission()
    }

    fun clearLog() {
        log = ""
    }

    private fun setFlag(id: String, value: Boolean) {
        enabled[id] = value
        prefs.edit().putBoolean(id, value).apply()
    }

    private fun exec(commands: List<String>, quiet: Boolean): String =
        commands.joinToString("\n") { cmd ->
            val out = Shell.run(cmd)
            when {
                quiet -> out
                out.isBlank() -> "OK: $cmd"
                else -> "$cmd\n$out"
            }
        }

    fun run(label: String, commands: List<String>, quiet: Boolean = false) {
        scope.launch {
            busy = true
            val result = withContext(Dispatchers.IO) { exec(commands, quiet) }
            log = "$label\n$result"
            busy = false
        }
    }

    fun setTweak(tweak: Tweak, on: Boolean) {
        // режимы анимаций исключают друг друга
        if (on && tweak.id == "anim_fast") setFlag("anim_off", false)
        if (on && tweak.id == "anim_off") setFlag("anim_fast", false)
        // частота экрана: 60 и 90 Гц исключают друг друга
        if (on && tweak.id == "refresh_high") setFlag("refresh_60", false)
        if (on && tweak.id == "refresh_60") setFlag("refresh_high", false)
        setFlag(tweak.id, on)
        run(
            (if (on) "Включено: " else "Выключено: ") + tweak.title,
            if (on) tweak.apply else tweak.revert
        )
    }

    fun setAnimScale(value: Float) {
        setFlag("anim_fast", false)
        setFlag("anim_off", false)
        val s = String.format(Locale.US, "%.2f", value)
        run(
            "Анимации: x$s",
            listOf(
                "settings put global window_animation_scale $s",
                "settings put global transition_animation_scale $s",
                "settings put global animator_duration_scale $s"
            )
        )
    }

    fun applyProfile(profile: Profile, riskUnlocked: Boolean) {
        scope.launch {
            busy = true
            val changes = Tweaks.toggles.filter { t ->
                if (t.risky && !riskUnlocked) false
                else (enabled[t.id] == true) != (t.id in profile.tweakIds)
            }
            val actions = Tweaks.actions.filter { it.id in profile.actionIds }
            val result = withContext(Dispatchers.IO) {
                val parts = mutableListOf<String>()
                // сначала выключаем, потом включаем: иначе откат одного режима
                // (например 60 Гц) затрёт включённый только что другой (90 Гц)
                val (turnOn, turnOff) = changes.partition { it.id in profile.tweakIds }
                turnOff.forEach { t -> parts += exec(t.revert, true) }
                turnOn.forEach { t -> parts += exec(t.apply, true) }
                actions.forEach { a -> parts += exec(a.commands, true) }
                parts.filter { it.isNotBlank() }.joinToString("\n")
            }
            changes.forEach { t -> setFlag(t.id, t.id in profile.tweakIds) }
            val skipped = if (!riskUnlocked && profile.tweakIds.any { id ->
                    Tweaks.toggles.firstOrNull { it.id == id }?.risky == true
                }) "\nРискованные пункты пропущены: включи режим «на свой риск»." else ""
            log = "Профиль применён: ${profile.title}$skipped" +
                if (result.isBlank()) "" else "\n$result"
            busy = false
        }
    }

    fun resetAll() {
        scope.launch {
            busy = true
            val active = Tweaks.toggles.filter { enabled[it.id] == true }
            val result = withContext(Dispatchers.IO) {
                active.joinToString("\n") { t -> exec(t.revert, true) }.trim()
            }
            active.forEach { setFlag(it.id, false) }
            log = "Все функции выключены (${active.size})" +
                if (result.isBlank()) "" else "\n$result"
            busy = false
        }
    }
}
