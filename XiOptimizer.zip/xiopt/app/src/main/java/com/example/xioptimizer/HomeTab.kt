package com.example.xioptimizer

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.Locale

data class Stats(
    val ramUsed: Float,
    val ramText: String,
    val storageUsed: Float,
    val storageText: String,
    val batteryLevel: Int,
    val batteryTemp: Float,
    val charging: Boolean
)

private fun gb(bytes: Long): String = String.format(Locale.US, "%.1f", bytes / 1073741824.0)

fun readStats(context: Context): Stats {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    val ramUsedBytes = mi.totalMem - mi.availMem
    val ramFraction = if (mi.totalMem > 0) ramUsedBytes.toFloat() / mi.totalMem else 0f

    val stat = StatFs(Environment.getDataDirectory().path)
    val total = stat.blockCountLong * stat.blockSizeLong
    val free = stat.availableBlocksLong * stat.blockSizeLong
    val storageFraction = if (total > 0) (total - free).toFloat() / total else 0f

    val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val temp = (intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL

    return Stats(
        ramUsed = ramFraction,
        ramText = "${gb(ramUsedBytes)} / ${gb(mi.totalMem)} ГБ",
        storageUsed = storageFraction,
        storageText = "${gb(total - free)} / ${gb(total)} ГБ",
        batteryLevel = if (level >= 0) level * 100 / scale else -1,
        batteryTemp = temp,
        charging = charging
    )
}

@Composable
fun DashboardCard() {
    val context = LocalContext.current
    var stats by remember { mutableStateOf(readStats(context)) }

    LaunchedEffect(Unit) {
        while (true) {
            stats = readStats(context)
            delay(2000)
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Состояние телефона", style = MaterialTheme.typography.titleMedium)

            Column {
                Text("Память (RAM): ${stats.ramText}", style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(
                    progress = { stats.ramUsed },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Column {
                Text("Хранилище: ${stats.storageText}", style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(
                    progress = { stats.storageUsed },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            val tempText = String.format(Locale.US, "%.1f", stats.batteryTemp)
            val hot = if (stats.batteryTemp >= 40f) " 🔥" else ""
            val charge = if (stats.charging) " ⚡" else ""
            Text(
                "Батарея: ${stats.batteryLevel}%$charge   Температура: $tempText °C$hot",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun HomeTab(state: AppState, ui: UiSettings) {
    val canRun = state.shizukuReady && !state.busy

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Xi Optimizer", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Оптимизация Redmi Note 11 без root, через Shizuku.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        item { DeviceCard() }
        item { ShizukuCard(state) }
        item { DashboardCard() }
        item { TurboStatusCard() }
        item { Text("Профили в один тап", style = MaterialTheme.typography.titleMedium) }

        items(Tweaks.profiles) { profile ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(profile.title, style = MaterialTheme.typography.titleSmall)
                    Text(profile.description, style = MaterialTheme.typography.bodySmall)
                    Row {
                        Button(
                            enabled = canRun,
                            onClick = { state.applyProfile(profile, ui.riskUnlocked) }
                        ) { Text("Применить") }
                    }
                }
            }
        }

        item {
            OutlinedButton(enabled = canRun, onClick = { state.resetAll() }) {
                Text("Сбросить все функции")
            }
        }
    }
}
