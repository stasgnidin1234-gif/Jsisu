package com.example.xioptimizer

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import java.util.Locale

@Composable
fun LookTab(ui: UiSettings) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Внешний вид приложения", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Подстрой приложение под себя. Всё сохраняется.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Тема", style = MaterialTheme.typography.titleSmall)
                    ChoiceRow(
                        options = listOf("Системная", "Светлая", "Тёмная"),
                        selected = ui.darkMode,
                        onSelect = { ui.updateDarkMode(it) }
                    )
                }
            }
        }

        item {
            SwitchCard(
                title = "Чёрная тема (AMOLED)",
                description = "Чистый чёрный фон в тёмной теме. Экономит батарею на AMOLED-экранах.",
                checked = ui.amoled,
                onChange = { ui.updateAmoled(it) }
            )
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Цвет акцента", style = MaterialTheme.typography.titleSmall)
                    AccentPalette.mapIndexed { i, p -> i to p.second }.chunked(4).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEach { (i, color) ->
                                val selected = ui.accent == i
                                Box(
                                    Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .then(
                                            if (selected) {
                                                Modifier.border(
                                                    3.dp,
                                                    MaterialTheme.colorScheme.onSurface,
                                                    CircleShape
                                                )
                                            } else {
                                                Modifier
                                            }
                                        )
                                        .clickable { ui.updateAccent(i) }
                                )
                            }
                        }
                    }
                    if (Build.VERSION.SDK_INT >= 31) {
                        if (ui.accent == DYNAMIC) {
                            Button(onClick = { ui.updateAccent(DYNAMIC) }) {
                                Text("Цвета из обоев (Material You) ✓")
                            }
                        } else {
                            OutlinedButton(onClick = { ui.updateAccent(DYNAMIC) }) {
                                Text("Цвета из обоев (Material You)")
                            }
                        }
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Размер текста", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "x" + String.format(Locale.US, "%.2f", ui.fontScale),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Slider(
                        value = ui.fontScale,
                        onValueChange = { ui.updateFontScale(it) },
                        valueRange = 0.8f..1.4f
                    )
                }
            }
        }

        item {
            SwitchCard(
                title = "Вибрация при переключении",
                description = "Лёгкий отклик при включении функций.",
                checked = ui.haptics,
                onChange = { ui.updateHaptics(it) }
            )
        }

        item {
            OutlinedButton(onClick = { ui.resetLook() }) { Text("Сбросить оформление") }
        }
    }
}
