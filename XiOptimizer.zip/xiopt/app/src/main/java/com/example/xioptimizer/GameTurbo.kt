package com.example.xioptimizer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ApplicationInfo
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Состояние Game Turbo для интерфейса. */
object TurboState {
    var active by mutableStateOf(false)
    var game by mutableStateOf("")
    var gameLabel by mutableStateOf("")
    var closed by mutableIntStateOf(0)
    var message by mutableStateOf("")

    fun reset() {
        active = false
        game = ""
        gameLabel = ""
        closed = 0
        message = ""
    }
}

/** Настройки Game Turbo и список игр. Сохраняются между запусками. */
class TurboPrefs(private val prefs: SharedPreferences) {
    var closeApps by mutableStateOf(prefs.getBoolean("close_apps", true))
        private set
    var dnd by mutableStateOf(prefs.getBoolean("dnd", true))
        private set
    var gameMode by mutableStateOf(prefs.getBoolean("game_mode", true))
        private set
    var tweaks by mutableStateOf(prefs.getBoolean("tweaks", true))
        private set
    var games by mutableStateOf(prefs.getStringSet("games", emptySet())?.toSet() ?: emptySet())
        private set

    fun updateCloseApps(v: Boolean) { closeApps = v; prefs.edit().putBoolean("close_apps", v).apply() }
    fun updateDnd(v: Boolean) { dnd = v; prefs.edit().putBoolean("dnd", v).apply() }
    fun updateGameMode(v: Boolean) { gameMode = v; prefs.edit().putBoolean("game_mode", v).apply() }
    fun updateTweaks(v: Boolean) { tweaks = v; prefs.edit().putBoolean("tweaks", v).apply() }

    fun addGame(pkg: String) {
        games = games + pkg
        prefs.edit().putStringSet("games", games).apply()
    }

    fun removeGame(pkg: String) {
        games = games - pkg
        prefs.edit().putStringSet("games", games).apply()
    }
}

object GameTurbo {
    const val EXTRA_PKG = "pkg"
    const val ACTION_STOP = "com.example.xioptimizer.STOP_TURBO"

    /** Эти функции включаются на время игры. */
    private val turboTweaks = listOf("anim_fast", "refresh_high", "wifi_scan_off")

    /** Эти функции затрагивает Turbo, после выхода возвращаем то, что включил сам пользователь. */
    private val affected = listOf("anim_fast", "anim_off", "refresh_high", "refresh_60", "wifi_scan_off")

    private val neverTouch = setOf("moe.shizuku.privileged.api", "moe.shizuku.manager")

    fun launch(context: Context, pkg: String) {
        val intent = Intent(context, GameTurboService::class.java).putExtra(EXTRA_PKG, pkg)
        ContextCompat.startForegroundService(context, intent)
    }

    fun requestStop(context: Context) {
        context.startService(
            Intent(context, GameTurboService::class.java).setAction(ACTION_STOP)
        )
    }

    private fun batch(commands: List<String>) {
        commands.chunked(25).forEach { Shell.run(it.joinToString("; ")) }
    }

    private fun tweak(id: String) = Tweaks.toggles.first { it.id == id }

    /** Сторонние приложения, которые закроем. Лаунчер, клавиатура, Shizuku и мы сами остаются. */
    private fun victims(context: Context, game: String): Set<String> {
        val pm = context.packageManager
        val keep = mutableSetOf(game, context.packageName)
        keep += neverTouch
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        pm.queryIntentActivities(home, 0).forEach { keep += it.activityInfo.packageName }
        Settings.Secure.getString(context.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')
            ?.let { keep += it }
        return pm.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName !in keep }
            .map { it.packageName }
            .toSet()
    }

    /** Блокирующая функция: вызывать не из главного потока. */
    fun begin(context: Context, pkg: String) {
        val tp = context.getSharedPreferences("turbo", Context.MODE_PRIVATE)
        val pm = context.packageManager
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        val closeApps = tp.getBoolean("close_apps", true)
        val useDnd = tp.getBoolean("dnd", true)
        val useGameMode = tp.getBoolean("game_mode", true)
        val useTweaks = tp.getBoolean("tweaks", true)

        val zen = Shell.run("settings get global zen_mode").trim().toIntOrNull() ?: 0
        val victims = if (closeApps) victims(context, pkg) else emptySet()

        tp.edit()
            .putBoolean("active", true)
            .putString("game", pkg)
            .putStringSet("restricted", victims)
            .putInt("zen", zen)
            .putBoolean("dnd_used", useDnd)
            .putBoolean("tweaks_used", useTweaks)
            .putBoolean("gamemode_used", useGameMode)
            .apply()

        TurboState.game = pkg
        TurboState.gameLabel = label
        TurboState.closed = victims.size
        TurboState.active = true
        TurboState.message = "Готовлю телефон..."

        if (useTweaks) {
            turboTweaks.forEach { id -> tweak(id).apply.forEach { Shell.run(it) } }
        }
        if (useGameMode) Shell.run("cmd game mode performance $pkg")
        if (useDnd) Shell.run("cmd notification set_dnd priority")
        Shell.run("cmd power set-fixed-performance-mode-enabled true")

        if (victims.isNotEmpty()) {
            TurboState.message = "Закрываю ${victims.size} приложений..."
            batch(victims.map { "am force-stop $it" })
            batch(victims.map { "cmd appops set $it RUN_IN_BACKGROUND ignore" })
        }
        Shell.run("am kill-all")

        TurboState.message = "Запускаю игру. Закрыто приложений: ${victims.size}"
        Shell.run("monkey -p $pkg -c android.intent.category.LAUNCHER 1")
        TurboState.message = "Turbo работает. Закрыто приложений: ${victims.size}"
    }

    /** Возвращает true, если всё восстановлено. Блокирующая функция. */
    fun restore(context: Context): Boolean {
        val tp = context.getSharedPreferences("turbo", Context.MODE_PRIVATE)
        if (!tp.getBoolean("active", false)) {
            TurboState.reset()
            return true
        }
        if (!Shell.hasPermission()) return false

        TurboState.message = "Возвращаю всё как было..."
        val pkg = tp.getString("game", "") ?: ""
        val restricted = tp.getStringSet("restricted", emptySet()) ?: emptySet()
        val zen = tp.getInt("zen", 0)

        batch(restricted.map { "cmd appops set $it RUN_IN_BACKGROUND default" })
        if (tp.getBoolean("gamemode_used", false) && pkg.isNotEmpty()) {
            Shell.run("cmd game mode standard $pkg")
        }
        Shell.run("cmd power set-fixed-performance-mode-enabled false")
        if (tp.getBoolean("dnd_used", false)) {
            val mode = when (zen) {
                1 -> "priority"
                2 -> "none"
                3 -> "alarms"
                else -> "off"
            }
            Shell.run("cmd notification set_dnd $mode")
        }
        if (tp.getBoolean("tweaks_used", false)) {
            turboTweaks.forEach { id -> tweak(id).revert.forEach { Shell.run(it) } }
            val userPrefs = context.getSharedPreferences("tweaks", Context.MODE_PRIVATE)
            affected.forEach { id ->
                if (userPrefs.getBoolean(id, false)) tweak(id).apply.forEach { Shell.run(it) }
            }
        }

        tp.edit()
            .putBoolean("active", false)
            .remove("restricted")
            .remove("game")
            .apply()
        TurboState.reset()
        return true
    }

    /** true / false, а если определить не удалось (например, Shizuku недоступен), то null. */
    fun inForeground(pkg: String): Boolean? {
        val out = Shell.run("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
        if (out.isBlank() || out.startsWith("Ошибка")) return null
        return out.contains(pkg)
    }
}

class GameTurboService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    @Volatile
    private var stopRequested = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showForeground("Game Turbo запускается...")

        if (intent?.action == GameTurbo.ACTION_STOP) {
            if (job?.isActive == true) {
                stopRequested = true
            } else {
                scope.launch { finish() }
            }
            return START_NOT_STICKY
        }

        val pkg = intent?.getStringExtra(GameTurbo.EXTRA_PKG)
        if (pkg == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (job?.isActive == true) return START_NOT_STICKY

        running = true
        stopRequested = false
        job = scope.launch {
            GameTurbo.begin(applicationContext, pkg)
            updateNotification("Turbo: ${TurboState.gameLabel}. Выйдешь из игры, и всё вернётся.")

            val power = getSystemService(PowerManager::class.java)
            val startedAt = System.currentTimeMillis()
            var seen = false
            var away = 0
            var tick = 0

            while (isActive && !stopRequested) {
                delay(1000)
                tick++
                if (tick % 2 != 0) continue
                if (!power.isInteractive) {
                    away = 0
                    continue
                }
                val fg = GameTurbo.inForeground(pkg) ?: continue
                if (fg) {
                    seen = true
                    away = 0
                } else if (seen || System.currentTimeMillis() - startedAt > 45_000) {
                    away++
                }
                // примерно 10 секунд вне игры, и Turbo выключается сам
                if (away >= 5) break
            }
            finish()
        }
        return START_NOT_STICKY
    }

    private fun finish() {
        GameTurbo.restore(applicationContext)
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        val ctx = applicationContext
        if (ctx.getSharedPreferences("turbo", Context.MODE_PRIVATE).getBoolean("active", false)) {
            Thread { GameTurbo.restore(ctx) }.start()
        }
        super.onDestroy()
    }

    private fun buildNotification(text: String) = run {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel("turbo", "Game Turbo", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, GameTurboService::class.java).setAction(GameTurbo.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        NotificationCompat.Builder(this, "turbo")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Game Turbo")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Выключить", stop)
            .build()
    }

    private fun showForeground(text: String) {
        val type = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, 1, buildNotification(text), type)
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
    }

    companion object {
        @Volatile
        var running = false
    }
}
