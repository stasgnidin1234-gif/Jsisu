package com.example.xioptimizer

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.util.Locale

/** Кодовые имена Redmi Note 11 (Snapdragon 680): spes и spesn (версия с NFC). */
private val note11Codenames = setOf("spes", "spesn")

private fun prop(key: String): String = try {
    Class.forName("android.os.SystemProperties")
        .getMethod("get", String::class.java)
        .invoke(null, key) as String
} catch (e: Throwable) {
    ""
}

data class DeviceData(
    val model: String,
    val codename: String,
    val android: String,
    val system: String,
    val ramGb: Float,
    val isNote11: Boolean
)

fun readDevice(context: Context): DeviceData {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)

    val hyper = prop("ro.mi.os.version.name")
    val miui = prop("ro.miui.ui.version.name")
    val system = when {
        hyper.isNotBlank() -> "HyperOS $hyper"
        miui.isNotBlank() -> "MIUI $miui"
        else -> "—"
    }
    val codename = Build.DEVICE.lowercase(Locale.US)
    return DeviceData(
        model = Build.MODEL,
        codename = codename,
        android = Build.VERSION.RELEASE,
        system = system,
        ramGb = mi.totalMem / 1073741824f,
        isNote11 = codename in note11Codenames
    )
}

@Composable
fun DeviceCard() {
    val context = LocalContext.current
    val d = remember { readDevice(context) }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (d.isNote11) {
                Text("Redmi Note 11 ✅", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Snapdragon 680, AMOLED 90 Гц. Все значения в приложении подобраны под эту модель.",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text("Устройство: ${d.model}", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Приложение настроено под Redmi Note 11 (кодовое имя spes). У тебя «${d.codename}», " +
                        "поэтому часть значений, например 90 Гц, может не подойти.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text(
                "Модель ${d.model} · ${d.codename}\n" +
                    "Android ${d.android} · ${d.system}\n" +
                    "Память: " + String.format(Locale.US, "%.1f", d.ramGb) + " ГБ",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
